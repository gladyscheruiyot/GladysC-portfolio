# Gladys Cheruiyot - Career Portfolio

This repository hosts the professional portfolio website for **Gladys Cheruiyot** — Digital Marketing & Creator Ecosystem Strategist.

## Live site (after GitHub Pages deployment)
Once published via GitHub Pages, access it at:
`https://<your-username>.github.io/gladys-portfolio/`
